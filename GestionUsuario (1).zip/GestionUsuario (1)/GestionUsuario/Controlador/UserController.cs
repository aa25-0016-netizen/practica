namespace GestionUsuario.Controllers
{
    public class UserController
    {
        //Definir atributos (class)
        List<User> lista_usuarios = new List<User>();
        User param_usuario = new User();

        //Crear Usuario

        public void CrearUsuarios(User datos)
        {
            //verificar si existe el usuario (db)
            if (lista_usuarios.Exists(x => x.name == datos.name))
            {
                Console.WriteLine($"El usuario {datos.name} ya existe");
                return;
            }
            //agregar usuario a la lista
            lista_usuarios.Add(datos);
            Console.WriteLine($"El usuario ha sido creado correctamente!");

        }

        //Editar Usuario
        //Eliminar Usuario
        //Listar Usuarios




        
    }


}