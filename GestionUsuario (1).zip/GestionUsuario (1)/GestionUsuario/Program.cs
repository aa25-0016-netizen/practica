﻿using System;
using System.Collections.Generic;

namespace CRUD_Usuarios
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
    }

    public class UserController
    {
        private List<User> usuarios = new List<User>();
        private int contadorId = 1;

        // CREATE
        public void Create(User user)
        {
            user.Id = contadorId++;
            usuarios.Add(user);
            Console.WriteLine("Usuario creado exitosamente.");
        }

        // EDIT
        public void Edit(int id)
        {
            User user = usuarios.Find(u => u.Id == id);
            if (user == null)
            {
                Console.WriteLine("Usuario no encontrado.");
                return;
            }

            Console.Write("Nuevo nombre: ");
            string nuevoNombre = Console.ReadLine();
            Console.Write("Nueva contraseña: ");
            string nuevaPass = Console.ReadLine();
            Console.Write("Nuevo correo: ");
            string nuevoCorreo = Console.ReadLine();

            user.Name = string.IsNullOrWhiteSpace(nuevoNombre) ? user.Name : nuevoNombre;
            user.Password = string.IsNullOrWhiteSpace(nuevaPass) ? user.Password : nuevaPass;
            user.Email = string.IsNullOrWhiteSpace(nuevoCorreo) ? user.Email : nuevoCorreo;

            Console.WriteLine("Usuario actualizado correctamente.");
        }

        // DELETE
        public void Delete(int id)
        {
            User user = usuarios.Find(u => u.Id == id);
            if (user == null)
            {
                Console.WriteLine("Usuario no encontrado.");
                return;
            }
            usuarios.Remove(user);
            Console.WriteLine("Usuario eliminado correctamente.");
        }

        // LIST
        public void List()
        {
            if (usuarios.Count == 0)
            {
                Console.WriteLine("No hay usuarios registrados.");
                return;
            }

            Console.WriteLine("\nLista de usuarios:");
            foreach (var user in usuarios)
            {
                Console.WriteLine($"ID: {user.Id}, Nombre: {user.Name}, Correo: {user.Email}");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            bool salir = false;
            UserController acciones = new UserController();

            while (!salir)
            {
                Console.WriteLine("\n--- Menú de Gestión de Usuarios ---");
                Console.WriteLine("1. Crear usuario");
                Console.WriteLine("2. Editar usuario");
                Console.WriteLine("3. Eliminar usuario");
                Console.WriteLine("4. Listar usuarios");
                Console.WriteLine("5. Salir");
                Console.Write("Selecciona una opción: ");
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        User nuevo = new User();
                        Console.Write("Nombre: ");
                        nuevo.Name = Console.ReadLine();
                        Console.Write("Contraseña: ");
                        nuevo.Password = Console.ReadLine();
                        Console.Write("Correo: ");
                        nuevo.Email = Console.ReadLine();
                        acciones.Create(nuevo);
                        break;

                    case "2":
                        Console.Write("ID del usuario a editar: ");
                        if (int.TryParse(Console.ReadLine(), out int idEdit))
                            acciones.Edit(idEdit);
                        else
                            Console.WriteLine("ID inválido.");
                        break;

                    case "3":
                        Console.Write("ID del usuario a eliminar: ");
                        if (int.TryParse(Console.ReadLine(), out int idDel))
                            acciones.Delete(idDel);
                        else
                            Console.WriteLine("ID inválido.");
                        break;

                    case "4":
                        acciones.List();
                        break;

                    case "5":
                        salir = true;
                        Console.WriteLine("Saliendo del sistema...");
                        break;

                    default:
                        Console.WriteLine("Opción no válida.");
                        break;
                }
            }
        }
    }
}
